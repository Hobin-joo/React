import React, { useState } from 'react'

const App = () => {
  //js
  const [data, setData] = useState([]);

  const addData = (newData) => {
    setData([...data, newData])
  }

  return (
    //jsx
    <>
    <div className='main'>
      <Input addData={addData}/>
      <MedalList />
    </div>

    </>
  )
}

export default App